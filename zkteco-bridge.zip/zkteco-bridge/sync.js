/**
 * ZKTeco → Firestore Bridge (multi-device)
 * -----------------------------------------
 * Runs on a PC/mini-PC on the SAME LOCAL NETWORK as your ZKTeco devices
 * (they only speak their native protocol on the LAN — cannot be reached
 * directly from a browser or from Firebase itself).
 *
 * Handles BOTH machines from one process:
 *   - Office Biometric   (type: 'attendance') → writes to `attendanceLogs`
 *   - Canteen Machine    (type: 'canteen')    → writes to `canteenLogs`
 *
 * Add more devices later by just adding another entry to CONFIG.DEVICES.
 *
 * ── SETUP ──────────────────────────────────────────────────────────
 *   1. npm init -y
 *   2. npm install node-zklib firebase-admin
 *   3. Download a Firebase service-account key:
 *        Firebase Console → Project Settings → Service Accounts →
 *        "Generate new private key" → save as serviceAccountKey.json
 *        in this same folder.
 *   4. In each employee record (dashboard → Employees → edit), fill:
 *        - "ZKTeco Device User ID"          → ID enrolled on the office
 *                                              attendance machine
 *        - "ZKTeco Canteen Device User ID"  → ID enrolled on the canteen
 *                                              machine (leave blank if
 *                                              it's the SAME ID as above)
 *   5. Edit CONFIG.DEVICES below with each device's LAN IP.
 *   6. Run:  node sync.js
 *      Keep it running with pm2 (`pm2 start sync.js --name zkteco-sync`)
 *      or as a systemd/Windows service so it survives reboots.
 * ────────────────────────────────────────────────────────────────── */

const ZKLib = require('node-zklib');

// ── FIXED FIREBASE IMPORT SYNTAX ──────────────────────────────────
const { initializeApp, cert } = require('firebase-admin/app');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');
const serviceAccount = require('./serviceAccountKey.json');

// ── CONFIG ───────────────────────────────────────────────────────
const CONFIG = {
  DEVICES: [
    {
      name: 'Office Biometric',
      type: 'attendance',      // → attendanceLogs
      ip: '192.168.16.72',     // <-- change to this device's LAN IP
      port: 4370,
      inPort: 4000,             // local UDP port node-zklib binds to (must differ per device)
    },
    {
      name: 'Canteen Machine — Zone A',
      type: 'canteen',          // → canteenLogs
      ip: '192.168.16.125',     // <-- change to this device's LAN IP
      port: 4370,
      inPort: 4001,             // different from the attendance device's inPort
    },
  ],
  TIMEOUT_MS: 10000,
  SYNC_INTERVAL_MS: 5 * 60 * 1000, // poll every 5 minutes
  LATE_AFTER_HOUR: 9,              // 9:30 AM cutoff for "Late" attendance status
  LATE_AFTER_MINUTE: 30,
  MEAL_CUTOFF_HOUR: 16,            // before 4 PM = Lunch, after = Dinner (adjust to your schedule)
};

// Initialize Firebase App modern way
initializeApp({ 
  credential: cert(serviceAccount) 
});

const db = getFirestore();

// Two maps built from the same employees collection:
//   attendanceIdMap  keyed by `deviceUserId`
//   canteenIdMap     keyed by `canteenDeviceUserId` (falls back to deviceUserId if not set)
let attendanceIdMap = {};
let canteenIdMap = {};

// ── FIXED: STRICT MAPPING AND FORMAT SANITIZATION ──────────────────
async function loadEmployeeMaps() {
  const snap = await db.collection('employees').get();
  const attMap = {};
  const canMap = {};
  
  snap.forEach(doc => {
    const e = doc.data();
    const info = { code: e.code || doc.id, name: e.name || 'Unknown', dept: e.dept || 'General' };
    
    // Clean string conversion to avoid type-mismatch or whitespace gaps
    if (e.deviceUserId !== undefined && e.deviceUserId !== null) {
      const officeIdClean = String(e.deviceUserId).trim();
      if (officeIdClean !== '') {
        attMap[officeIdClean] = info;
      }
    }
    
    // Dynamic canteen mapping setup with proper fallback check
    const canteenIdRaw = (e.canteenDeviceUserId !== undefined && e.canteenDeviceUserId !== null && String(e.canteenDeviceUserId).trim() !== '') 
                         ? e.canteenDeviceUserId 
                         : e.deviceUserId;
                         
    if (canteenIdRaw !== undefined && canteenIdRaw !== null) {
      const canteenIdClean = String(canteenIdRaw).trim();
      if (canteenIdClean !== '') {
        canMap[canteenIdClean] = info;
      }
    }
  });
  
  attendanceIdMap = attMap;
  canteenIdMap = canMap;
  console.log(`Loaded ${Object.keys(attMap).length} attendance mappings, ${Object.keys(canMap).length} canteen mappings`);
}

function classifyAttendanceStatus(checkInDate) {
  const h = checkInDate.getHours();
  const m = checkInDate.getMinutes();
  if (h > CONFIG.LATE_AFTER_HOUR || (h === CONFIG.LATE_AFTER_HOUR && m > CONFIG.LATE_AFTER_MINUTE)) {
    return 'Late';
  }
  return 'Present';
}

function classifyMeal(ts) {
  return ts.getHours() < CONFIG.MEAL_CUTOFF_HOUR ? 'Lunch' : 'Dinner';
}

function dateKey(d) {
  return d.toISOString().slice(0, 10); // YYYY-MM-DD
}

// ── ATTENDANCE DEVICE SYNC ───────────────────────────────────────
async function syncAttendanceDevice(device, punches) {
  const grouped = {}; // `${uid}_${day}` -> [Date, ...]
  punches.forEach(({ uid, ts }) => {
    const key = `${uid}_${dateKey(ts)}`;
    (grouped[key] ||= []).push(ts);
  });

  const batch = db.batch();
  let written = 0;

  for (const key of Object.keys(grouped)) {
    const [uid, day] = key.split('_');
    const emp = attendanceIdMap[uid];
    if (!emp) {
      console.warn(`[${device.name}] No employee mapped for device user ID ${uid} — set "ZKTeco Device User ID" for that employee`);
      continue;
    }
    const times = grouped[key].sort((a, b) => a - b);
    const inTime = times[0];
    const outTime = times.length > 1 ? times[times.length - 1] : null;

    const docId = `${emp.code}_${day}`; // idempotent re-syncs
    batch.set(db.collection('attendanceLogs').doc(docId), {
      empCode: emp.code,
      empName: emp.name,
      dept: emp.dept,
      date: day,
      inTime: inTime.toISOString(),
      outTime: outTime ? outTime.toISOString() : null,
      status: classifyAttendanceStatus(inTime),
      source: 'zkteco-auto-sync',
      syncedAt: FieldValue.serverTimestamp(),
    }, { merge: true });
    written++;
  }

  if (written > 0) await batch.commit();
  console.log(`[${device.name}] Synced ${written} daily attendance record(s)`);
}

// ── CANTEEN DEVICE SYNC ──────────────────────────────────────────
async function syncCanteenDevice(device, punches) {
  const batch = db.batch();
  let written = 0;

  for (const { uid, ts } of punches) {
    const meal = classifyMeal(ts);
    const emp = canteenIdMap[uid];
    const day = dateKey(ts);

    // One deduction per employee per meal per day — later scans just
    // update the timestamp instead of creating duplicate charges.
    const docId = emp ? `${emp.code}_${day}_${meal}` : `unmatched_${uid}_${ts.getTime()}`;
    batch.set(db.collection('canteenLogs').doc(docId), {
      empCode: emp ? emp.code : uid,
      empName: emp ? emp.name : `Unrecognized ID ${uid}`,
      meal,
      device: device.name,
      ts: ts.toISOString(),
      status: emp ? 'Matched' : 'Unmatched',
      source: 'zkteco-auto-sync',
      syncedAt: FieldValue.serverTimestamp(),
    }, { merge: true });
    written++;

    if (!emp) console.warn(`[${device.name}] Unrecognized canteen scan from device user ID ${uid}`);
  }

  if (written > 0) await batch.commit();
  console.log(`[${device.name}] Synced ${written} canteen scan(s)`);
}

// ── PER-DEVICE POLL ──────────────────────────────────────────────
async function syncDevice(device) {
  const zk = new ZKLib(device.ip, device.port, CONFIG.TIMEOUT_MS, device.inPort);
  try {
    await zk.createSocket();
    console.log(`[${new Date().toLocaleString()}] [${device.name}] Connected at ${device.ip}`);

    const logs = await zk.getAttendances(); // { data: [ { userId, timestamp, ... } ] }
    
    const punches = [];
    logs.data.forEach(rec => {
      // FIXED: Dynamic fallback key validation check for device logs
      const uidRaw = rec.deviceUserId ?? rec.userId ?? rec.uid ?? rec.userSn;
      const timeRaw = rec.timestamp ?? rec.recordTime ?? rec.time;
      
      if (uidRaw !== undefined && uidRaw !== null && timeRaw) {
        punches.push({
          uid: String(uidRaw).trim(), // Trim added for exact machine-to-cloud matching
          ts: new Date(timeRaw)
        });
      }
    });

    console.log(`[${device.name}] Pulled ${punches.length} raw punches`);

    if (device.type === 'attendance') await syncAttendanceDevice(device, punches);
    else if (device.type === 'canteen') await syncCanteenDevice(device, punches);
    else console.warn(`Unknown device type "${device.type}" for ${device.name}`);
  } catch (err) {
    console.error(`[${device.name}] Sync failed:`, err.message);
  } finally {
    try { await zk.disconnect(); } catch (_) {}
  }
}

async function syncAllDevices() {
  for (const device of CONFIG.DEVICES) {
    await syncDevice(device); // sequential execution
  }
}

async function main() {
  await loadEmployeeMaps();
  await syncAllDevices();
  setInterval(async () => {
    await loadEmployeeMaps(); // pick up newly added employees / mappings
    await syncAllDevices();
  }, CONFIG.SYNC_INTERVAL_MS);
  console.log(`Bridge running for ${CONFIG.DEVICES.length} device(s) — syncing every ${CONFIG.SYNC_INTERVAL_MS / 60000} minute(s). Press Ctrl+C to stop.`);
}

main();
