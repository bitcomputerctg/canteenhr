# ZKTeco → Firestore Bridge

Pushes real punch data from **2 ZKTeco devices** into the same Firestore project
used by the CanteenPay HR Dashboard:

| Device            | Type          | Firestore collection |
|--------------------|---------------|------------------------|
| Office Biometric    | `attendance`  | `attendanceLogs`       |
| Canteen Machine — Zone A | `canteen` | `canteenLogs`         |

## 1. Install

Run these inside this folder:

```bash
npm install
```

## 2. Get a Firebase service-account key

1. Go to **Firebase Console → Project Settings → Service Accounts**.
2. Click **Generate new private key**.
3. Save the downloaded file in this folder as exactly:
   ```
   serviceAccountKey.json
   ```
   (Keep this file private — never commit it or share it publicly, it grants
   full admin access to your Firestore project.)

## 3. Set each employee's Device User IDs

In the dashboard → **Employees** → edit each employee and fill in:
- **ZKTeco Device User ID** — the ID they're enrolled under on the office
  attendance machine.
- **ZKTeco Canteen Device User ID** — the ID they're enrolled under on the
  canteen machine (leave blank if it's the same ID as above).

Scans from a device user ID with no matching employee show up as
**Unmatched** in the dashboard instead of being silently dropped.

## 4. Set each device's LAN IP

Open `sync.js` and edit the two entries in `CONFIG.DEVICES` — replace `ip`
with each machine's actual local network IP address (find this from the
device's own menu, or your router's connected-devices list).

```js
DEVICES: [
  { name: 'Office Biometric',           type: 'attendance', ip: '192.168.x.x', port: 4370, inPort: 4000 },
  { name: 'Canteen Machine — Zone A',   type: 'canteen',    ip: '192.168.x.x', port: 4370, inPort: 4001 },
],
```

## 5. Run it

```bash
npm start
```

You should see console output like:

```
Loaded 12 attendance mappings, 12 canteen mappings
[Office Biometric] Connected at 192.168.16.72
[Office Biometric] Pulled 8 raw punches
[Office Biometric] Synced 8 daily attendance record(s)
[Canteen Machine — Zone A] Connected at 192.168.16.125
...
Bridge running for 2 device(s) — syncing every 5 minute(s). Press Ctrl+C to stop.
```

The dashboard's **Sync Devices** page and the sidebar sync indicator will
pick these records up automatically (it listens to Firestore in real time —
no manual "Sync Now" click needed once this is running).

## 6. Keep it running permanently

This process needs to stay alive on a PC on the same LAN as the devices.
Use a process manager so it survives reboots/crashes:

```bash
npm install -g pm2
pm2 start sync.js --name zkteco-sync
pm2 save
pm2 startup   # follow the printed instructions to enable on-boot start
```

## Troubleshooting

- **"Sync failed" / connection errors** — check the device IP is correct and
  reachable (`ping <ip>`), and that port `4370` isn't blocked by a firewall.
- **Everything shows "Unmatched"** — the employee's Device User ID field
  doesn't match what's enrolled on the machine; double-check for typos or
  leading/trailing spaces.
- **Dashboard still shows demo data** — confirm `firebaseConfig` in the
  dashboard HTML points to the same Firebase project as this bridge's
  `serviceAccountKey.json`.
